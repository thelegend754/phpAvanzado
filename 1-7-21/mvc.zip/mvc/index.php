<?php


?>

<a href="controller.php?arc=1" >article 1</a>
<a href="controller.php?arc=2" >article 2</a>

