<?php


function getData($arcId){
$link = mysqli_connect("localhost", "root", "", "eshop");
$result = mysqli_query($link, "select * from products where id = $arcId");

$data = mysqli_fetch_all($result, MYSQLI_ASSOC);
return $data;
}
 


