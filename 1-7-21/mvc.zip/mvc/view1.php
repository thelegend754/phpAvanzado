<?php
echo $_GET['data'];
?>

