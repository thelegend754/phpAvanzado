<?php
require 'model.php';
if(isset($_GET['arc'])){
    if($_GET['arc']==1){
        $data = getData(1);
        header("location:view1.php?data={$data[0]['title']}");
        
    }elseif ($_GET['arc']==2) {
        $data = getData(2);
        header("location:view2.php?data={$data[0]['title']}");
    }
}
